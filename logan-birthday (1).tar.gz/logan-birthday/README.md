# 🎉 Happy Birthday Logan — Website

A premium, animated birthday surprise website.

## Project Structure

```
logan-birthday/
├── index.html          ← Main page (don't rename)
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← All animations & logic
├── images/
│   ├── photo1.jpg      ← Logan's photos (add more here)
│   ├── photo2.jpg
│   └── ...
└── music/
    └── birthday.mp3    ← Background music
```

---

## ✏️ How to Edit Content

Open **`js/main.js`** and edit the `CONFIG` block at the top:

```js
const CONFIG = {
  name: "Logan",           // ← Name displayed
  message: `...`,          // ← Birthday message text
  photos: [
    { src: "images/photo1.jpg", caption: "Caption here" },
    // Add more photos here
  ],
  musicSrc: "music/birthday.mp3"  // ← Music file path
};
```

---

## 📸 Adding More Photos

1. Put your photo file in the `/images/` folder
2. In `js/main.js`, add a new line to the `photos` array:
   ```js
   { src: "images/photo7.jpg", caption: "Your caption" },
   ```

---

## 🎵 Changing Music

1. Put your MP3 in the `/music/` folder
2. In `index.html`, update the `<source src="...">` line
3. In `js/main.js`, update `musicSrc` in CONFIG

---

## 🚀 Deploying on Replit (from GitHub)

1. Push this entire folder to a GitHub repository
2. Go to [replit.com](https://replit.com) → Create Repl → Import from GitHub
3. Paste your repo URL → Import
4. Replit detects it as HTML automatically
5. Click **Run** → get your public shareable link

## 🌐 Other Hosts

| Host | Steps |
|------|-------|
| **GitHub Pages** | Repo Settings → Pages → Deploy from branch (main / root) |
| **Netlify** | Drag the folder onto netlify.com/drop |
| **Vercel** | `vercel --prod` in the folder, or connect GitHub repo |

---

## 🎨 Changing Colors

Edit `:root` variables at the top of `css/style.css`:

```css
:root {
  --gold:   #d4af37;   /* Main gold */
  --blue:   #1a3a8f;   /* Royal blue */
  --black:  #060810;   /* Background */
}
```
